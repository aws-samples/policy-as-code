---
title: "Policy as Code in Action"
weight: 80
---
Policy as code can be implemented thoughout the lifecycle of a workload. It can be preventative, detective, or both. This section explores implementing policy as code throughout the lifecycle of a workload.
