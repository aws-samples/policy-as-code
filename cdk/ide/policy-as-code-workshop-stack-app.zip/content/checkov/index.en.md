---
title: "Checkov"
weight: 40
---

This section focuses on using the Open Source tool [Checkov](https://github.com/bridgecrewio/checkov). Checkov is a static code analysis tool for Infrastructure as Code. Checkov works with CloudFormation and Terraform and a variety of other popular tools.

One of the main benefits of using Checkov is the large built in ruleset. 