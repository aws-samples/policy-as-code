---
title: "Installing the tools"
weight: 40
---
Refer to the sections that address specific tools of interest:
- [AWS CloudFormation Guard Installation](/cfn-guard/cfn-guard-install)
- [Regula/Open Policy Agent Installation](/opa/regula-install)
- [Checkov Installation](/checkov/install-checkov)
- [Cfn Lint Installation](/cfn-lint/install-cfn-lint)