---
title: "CFN Lint"
weight: 50
---

This section focuses on using AWS CloudFormation with the Open Source tool (CFN Lint)[https://github.com/aws-cloudformation/cfn-lint]. CFN Lint is a Python based CLI for scanning CloudFormation templates. 

CFN Lint has a a variety of preset checks and tests configured.