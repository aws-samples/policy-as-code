from __future__ import print_function
import json
import urllib.parse
import boto3
import logging
import traceback
#import cfnresponse
import time
import urllib3
import json

logger = logging.getLogger()
logger.setLevel(logging.INFO)

SUCCESS = "SUCCESS"
FAILED = "FAILED"


def lambda_handler(event, context):
    print("Received event: " + json.dumps(event, indent=2))

    logger.debug('Event: {}'.format(event))
    logger.debug('Context: {}'.format(context))

    # init response
    props = event
    response_status = FAILED
    response_data = {}

    # Immediately respond on Delete
    if event['RequestType'] == 'Delete':
        try:
            logger.debug('Event: {}'.format(event))
            send_cfnresponse(event, context, SUCCESS,
                             responseData, 'CustomResourcePhysicalID')
        except Exception as e:
            logger.error(e, exc_info=True)
            responseData = {'Error': traceback.format_exc(e)}
            send_cfnresponse(event, context, FAILED,
                             responseData, 'CustomResourcePhysicalID')

    if event['RequestType'] == 'Create':
        try:
            # Open AWS clients
            ec2 = boto3.client('ec2')

            # Get the Instance object from the InstanceId
            instance = ec2.describe_instances(Filters=[
                                              {'Name': 'instance-id', 'Values': [props['InstanceId']]}])['Reservations'][0]['Instances'][0]
            instanceId = instance['InstanceId']

            # Create the IamInstanceProfile request object
            iam_instance_profile = {
                'Arn': props['InstanceProfileArn']
            }

            # Wait for Instance to become ready before adding Role
            instance_state = instance['State']['Name']
            while instance_state != 'running':
                time.sleep(5)
                instance_state = ec2.describe_instances(
                    InstanceIds=[instance['InstanceId']])
            if 'IamInstanceProfile' in instance:
                association_id = ec2.describe_iam_instance_profile_associations(
                    Filters=[{'Name': 'instance-id', 'Values': [instance['InstanceId']]}])['IamInstanceProfileAssociations'][0]['AssociationId']
                ec2.replace_iam_instance_profile_association(
                    IamInstanceProfile=iam_instance_profile, AssociationId=association_id)
            else:
                ec2.associate_iam_instance_profile(
                    IamInstanceProfile=iam_instance_profile, InstanceId=instance['InstanceId'])

            responseData = {
                'Success': 'Role added to instance'+instance['InstanceId']+'.'}
            send_cfnresponse(event, context, SUCCESS,
                             responseData, 'CustomResourcePhysicalID')
        except Exception as e:
            logger.error(e, exc_info=True)
            responseData = {'Error': traceback.format_exc(e)}
            send_cfnresponse(event, context, FAILED,
                             responseData, 'CustomResourcePhysicalID')


http = urllib3.PoolManager()

# TODO: Make this function's source a zip and add cfnresponse as a dependency
# See: https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/cfn-lambda-function-code-cfnresponsemodule.html


def send_cfnresponse(event, context, responseStatus, responseData, physicalResourceId=None, noEcho=False, reason=None):
    responseUrl = event['ResponseURL']

    print(responseUrl)

    responseBody = {
        'Status': responseStatus,
        'Reason': reason or "See the details in CloudWatch Log Stream: {}".format(context.log_stream_name),
        'PhysicalResourceId': physicalResourceId or context.log_stream_name,
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'NoEcho': noEcho,
        'Data': responseData
    }

    json_responseBody = json.dumps(responseBody)

    print("Response body:")
    print(json_responseBody)

    headers = {
        'content-type': '',
        'content-length': str(len(json_responseBody))
    }

    try:
        response = http.request(
            'PUT', responseUrl, headers=headers, body=json_responseBody)
        print("Status code:", response.status)

    except Exception as e:

        print("send(..) failed executing http.request(..):", e)
